sim_scan_2.cu	    基于CUDA分别扫描三张数据表

sim_scan_2.cpp	  基于CUDA分别扫描三张数据表

scan_agg.cu		基于 CUDA 扫描三张表+运算

scan_agg.cpu		基于 CUDA 扫描三张表+运算

utils.cuh		       CUDA 工具代码

data_structures.h 	定义三张表的列名